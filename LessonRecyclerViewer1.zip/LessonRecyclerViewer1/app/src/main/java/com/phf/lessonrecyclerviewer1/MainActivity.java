package com.phf.lessonrecyclerviewer1;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;

import com.phf.lessonrecyclerviewer1.adapters.NotesRecyclerAdapter;
import com.phf.lessonrecyclerviewer1.model.Note;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private RecyclerView mrecyclerview;
    private ArrayList<Note> mNotes = new ArrayList<>();
    private NotesRecyclerAdapter mNotesRecyclerAdapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mrecyclerview = findViewById(R.id.recyclerview);
        initRecycler();
        inserNotes();
    }
    private void inserNotes(){
        for(int i =0;i<100;i++){
            Note note = new Note();
            note.setTitle("Title #" + i);
            note.setContent("Content #");
            note.setTimeStamp("Jan2019");
            mNotes.add(note);
        }
        mNotesRecyclerAdapter.notifyDataSetChanged();
    }
    private void initRecycler(){
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        mrecyclerview.setLayoutManager(linearLayoutManager);
        mNotesRecyclerAdapter = new NotesRecyclerAdapter(mNotes);
        mrecyclerview.setAdapter(mNotesRecyclerAdapter);
    }
}
