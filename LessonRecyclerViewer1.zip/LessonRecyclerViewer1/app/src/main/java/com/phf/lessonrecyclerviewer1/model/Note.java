package com.phf.lessonrecyclerviewer1.model;

public class Note {
    private String Title;
    private String TimeStamp;
    private String Content;

    public Note(String title, String timeStamp, String content) {
        Title = title;
        TimeStamp = timeStamp;
        Content = content;
    }

    public Note() {
    }

    public String getTitle() {
        return Title;
    }

    public void setTitle(String title) {
        Title = title;
    }

    public String getTimeStamp() {
        return TimeStamp;
    }

    public void setTimeStamp(String timeStamp) {
        TimeStamp = timeStamp;
    }

    public String getContent() {
        return Content;
    }

    public void setContent(String content) {
        Content = content;
    }
}
