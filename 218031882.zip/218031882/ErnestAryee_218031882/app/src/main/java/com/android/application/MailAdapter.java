package com.android.application;


import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.android.ErnestAryee_218031882.R;

import java.lang.reflect.Field;
import java.util.List;




public class MailAdapter extends RecyclerView.Adapter<MailViewHolder> {

    private List<EmailData> mEmailData;
    private Context mContext;


    public MailAdapter(Context mContext, List<EmailData> mEmailData) {
        this.mEmailData = mEmailData;
        this.mContext = mContext;
    }

    @Override
    public MailViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.recyclerview_mail_item,
                parent, false);
        return new MailViewHolder(view);
    }

    @Override
    public void onBindViewHolder(final MailViewHolder holder, int position) {
        holder.theSender.setText(mEmailData.get(position).getmSender());
        holder.theEmailTitle.setText(mEmailData.get(position).getmTitle());
        holder.theEmailDetails.setText(mEmailData.get(position).getmDetails());
        holder.theEmailTime.setText(mEmailData.get(position).getmTime());
        holder.imageView.setImageResource(mEmailData.get(position).getImageId());

        final Class drawableClass = R.drawable.class;
        final Field[] fields =drawableClass.getFields();

        holder.mLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent mIntent = new Intent(mContext, DetailActivity.class);
                mIntent.putExtra("sender", holder.theSender.getText().toString());
                mIntent.putExtra("title", holder.theEmailTitle.getText().toString());
                mIntent.putExtra("details", holder.theEmailDetails.getText().toString());
                mIntent.putExtra("time", holder.theEmailTime.getText().toString());
                mContext.startActivity(mIntent);
            }
        });

    }

    @Override
    public int getItemCount() {
        return mEmailData.size();
    }
}

class MailViewHolder extends RecyclerView.ViewHolder {


    ImageView imageView;
    TextView theSender;
    TextView theEmailTitle;
    TextView theEmailDetails;
    TextView theEmailTime;
    RelativeLayout mLayout;

    MailViewHolder(View itemView) {
        super(itemView);

        imageView =(ImageView) itemView.findViewById(R.id.tvlistview_image) ;
        theSender = itemView.findViewById(R.id.tvEmailSender);
        theEmailTitle = itemView.findViewById(R.id.tvEmailTitle);
        theEmailDetails = itemView.findViewById(R.id.tvEmailDetails);
        theEmailTime = itemView.findViewById(R.id.tvEmailTime);
        mLayout = itemView.findViewById(R.id.layout);

    }
}
