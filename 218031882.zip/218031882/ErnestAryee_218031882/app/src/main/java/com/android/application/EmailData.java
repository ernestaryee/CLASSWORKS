package com.android.application;

public class EmailData {
    private int imageId;
    private String theSender;
    private String theTitle;
    private String theDetails;
    private String theTime;


    public EmailData(Integer imageId, String mSender, String mTitle, String mDetails, String mTime) {
        this.imageId =imageId;
        this.theSender = mSender;
        this.theTitle = mTitle;
        this.theDetails = mDetails;
        this.theTime = mTime;

    }

    public EmailData(){

    }
    public int getImageId() {
        return imageId;
    }

    public String getmSender() {
        return theSender;
    }

    public String getmTitle() {
        return theTitle;
    }

    public String getmDetails() {
        return theDetails;
    }

    public String getmTime() {
        return theTime;
    }



}
