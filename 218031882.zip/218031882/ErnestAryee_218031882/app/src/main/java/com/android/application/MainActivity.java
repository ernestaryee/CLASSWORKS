package com.android.application;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;

import com.android.ErnestAryee_218031882.R;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    Toolbar mToolbar;
    RecyclerView mRecyclerView;
    List<EmailData> mEmailData = new ArrayList<>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mToolbar = findViewById(R.id.toolbar);
        mToolbar.setTitle(R.string.app_name);

        mRecyclerView = findViewById(R.id.recyclerView);

        LinearLayoutManager mLinearLayoutManager = new LinearLayoutManager(MainActivity.this,
                LinearLayoutManager.VERTICAL, false);

        mRecyclerView.addItemDecoration(new DividerItemDecoration(MainActivity.this,
                DividerItemDecoration.VERTICAL));

        mRecyclerView.setLayoutManager(mLinearLayoutManager);

        EmailData mEmail = new EmailData(R.drawable.braid,"Renox Acheampong", "Code Reviewer",
                "Review: The code looks complex, try to create functions to group codes and leave spaces between functions",
                "10:42am");
        mEmailData.add(mEmail);
        mEmail = new EmailData(R.drawable.audience,"Gilbert Adu Acheampong", "Beta Tester",
                "Would i be paid after this 54th testing. I'm tired",
                "16:04pm");
        mEmailData.add(mEmail);
        mEmail = new EmailData(R.drawable.autokey,"Emmanuel Addo", "IT Support Officer",
                "4 of our Pendrives were missing last Friday, anyone seen it?",
                "18:44pm");
        mEmailData.add(mEmail);
        mEmail = new EmailData(R.drawable.autocad,"Daniel Antwi", "Senior Developer",
                "I need more time to finish implementing the image, it looks complex",
                "20:04pm");
        mEmailData.add(mEmail);
        mEmail = new EmailData(R.drawable.autoplus,"Ernest Aryee", "Tech enthusiast",
                "Woow, this app looks great. Can anyone teach me how to program?",
                "09:04am");
        mEmailData.add(mEmail);
        mEmail = new EmailData(R.drawable.audex,"Emmanuel Agyei", "Go to Programmer", "About the problem you were facing, it has been fixed, it was just a little error with how you wrote your codes",
                "01:04am");
        mEmailData.add(mEmail);
        mEmail = new EmailData(R.drawable.avogadro,"Renox Acheampong", "Code Reviewer",
                "Review: The code looks complex, try to create functions to group codes and leave spaces between functions",
                "10:42am");
        mEmailData.add(mEmail);
        mEmail = new EmailData(R.drawable.auralquiz,"Gilbert Adu Acheampong", "Beta Tester",
                "Would i be paid after this 54th testing. I'm tired",
                "16:04pm");
        mEmailData.add(mEmail);
        mEmail = new EmailData(R.drawable.birdfont,"Emmanuel Addo", "IT Support Officer",
                "4 of our Pendrives were missing last Friday, anyone seen it?",
                "18:44pm");
        mEmailData.add(mEmail);
        mEmail = new EmailData(R.drawable.beryl,"Daniel Antwi", "Senior Developer",
                "I need more time to finish implementing the image, it looks complex",
                "20:04pm");
        mEmailData.add(mEmail);
        mEmail = new EmailData(R.drawable.bino,"Ernest Aryee", "Tech enthusiast",
                "Woow, this app looks great. Can anyone teach me how to program?",
                "09:04am");
        mEmailData.add(mEmail);
        mEmail = new EmailData(R.drawable.bleachbit,"Emmanuel Agyei", "Go to Programmer", "About the problem you were facing, it has been fixed, it was just a little error with how you wrote your codes",
                "01:04am");
        mEmailData.add(mEmail);

        MailAdapter mMailAdapter = new MailAdapter(MainActivity.this, mEmailData);
        mRecyclerView.setAdapter(mMailAdapter);

    }
}
